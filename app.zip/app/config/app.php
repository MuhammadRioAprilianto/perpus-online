<?php
// Deteksi apakah sedang berjalan di local (localhost) atau di cPanel (production)
$isLocal = in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', '::1']) || (isset($_SERVER['SERVER_ADDR']) && $_SERVER['SERVER_ADDR'] === '127.0.0.1');

if ($isLocal) {
    define('BASEURL', 'http://localhost/perpus-online/public');
    define('APP_ROOT', dirname(__DIR__));
    define('PUBLIC_ROOT', APP_ROOT . '/../public');
} else {
    // Pengaturan URL dan Path untuk cPanel Production
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'] ?? 'pdwp8946.pdwp.my.id'; // Fallback ke host saat ini
    define('BASEURL', $protocol . $host);
    
    define('APP_ROOT', '/home/pdwp8946/app');
    define('PUBLIC_ROOT', '/home/pdwp8946/public_html');
}
define('BASE_URL', BASEURL);

// Nama Aplikasi
define('APP_NAME', 'Website Perpustakaan Online');

// Atur zona waktu ke WIB (penting untuk perhitungan timer 15 menit nanti)
date_default_timezone_set('Asia/Jakarta');